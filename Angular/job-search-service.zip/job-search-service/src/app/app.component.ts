import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './ui/header/header.component';
import { JobDetailsComponent } from './job/job-details/job-details.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, JobDetailsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  job = {
  title: 'job-search-service',
  company: 'Tech Corp',
  description: 'Looking for a skilled frontend developer with experience in Angular.'
};
}
